console.log("Script A");

function testA() {
console.log("tested A");
}