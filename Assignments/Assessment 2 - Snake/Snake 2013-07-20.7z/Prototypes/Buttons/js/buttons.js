/******************************************
*	Constants
******************************************/


/******************************************
*	Globals
******************************************/
var btns = new Array();

/*
	
*/

function SetupButtons() {
	
	// Set up the handler for the canvas
	$("#" + CANVAS_NAME).click(function(e) {
		ClickEvent(e);
	});
	
	// Set up event handler for mouse move
	$("#" + CANVAS_NAME).mousemove(function(e) {
		MouseMoveEvent(e);
	});
	
	// Create some buttons
	
	btns[0] = new Button("#0000FF", 10, 10, 10, 10);
	btns[1] = new Button("#0000FF", 10, 40, 10, 10);
	btns[2] = new Button("#0000FF", 10, 70, 10, 10);
	btns[3] = new Button("#0000FF", 10, 100, 10, 10);
	btns[4] = new Button("#0000FF", 10, 120, 10, 10);
	
	Refresh();

}

function Refresh() {
	ClearCanvas();
	
	for (var i = 0; i<5; i++) {
		canvasContext.fillStyle = btns[i].colour;
		canvasContext.fillRect(btns[i].x, btns[i].y, btns[i].x + btns[i].w, btns[i].y + btns[i].h);
	}
}

function ClearCanvas() {
	// Clear the canvas using default colour
	canvasContext.fillStyle = CANVAS_COLOUR;
	canvasContext.fillRect(0, 0, canvas.width,canvas.height);
}

function ClickEvent(e) {
	// Check if mouse is inside any buttons.
	// If it is call the corresponding function.
	
}

function MouseMoveEvent(e) {
	// Check if the mouse is inside any button.
	// If it is inside a button change the button state to hover.
	// When it leaves the button change the button state to normal.
	
}

function Button(colour, x, y, w, h) {
	this.colour=colour;
	this.x=x;
	this.y=y;
	this.w=w;
	this.h=h;
}


