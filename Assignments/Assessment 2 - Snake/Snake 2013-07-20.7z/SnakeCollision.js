
function CheckCollisionWithSnake() {

	//Loop through all the parts and see if the head hits any
	for (var i = 1; i < snake.length-1; i++) {
		if(snake.body[0].x == snake.body[i].x && snake.body[0].y == snake.body[i].y) {
			return true;
		}
	}

}
