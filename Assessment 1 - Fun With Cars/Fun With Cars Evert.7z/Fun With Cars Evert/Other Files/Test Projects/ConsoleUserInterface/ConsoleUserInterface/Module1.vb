﻿Module Module1

    Public Class StatusStrip

        Public Sub test()
            Console.Write("TESTED")
        End Sub

    End Class
End Module
