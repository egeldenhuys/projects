﻿Module Module1

    Sub Main()

    End Sub

    Public Class Box

        Public Sub New()

        End Sub

        Public Sub SetHeader(ByVal str As String)

        End Sub

        Public Sub
    End Class
End Module
