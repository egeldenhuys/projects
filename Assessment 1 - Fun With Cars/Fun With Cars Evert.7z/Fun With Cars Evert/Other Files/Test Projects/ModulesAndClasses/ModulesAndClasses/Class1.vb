﻿Public Class Class1

    Public Function getStuff() As String

        Return "Stuff" & MOARSTUFF()
    End Function

    Private Function MOARSTUFF() As String

        Return "BABIES"
    End Function
End Class
